---
name: Editorial Elegance
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#4d4635'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#7f7663'
  outline-variant: '#d0c5af'
  surface-tint: '#735c00'
  primary: '#735c00'
  on-primary: '#ffffff'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#e9c349'
  secondary: '#645d5d'
  on-secondary: '#ffffff'
  secondary-container: '#ebe0e0'
  on-secondary-container: '#6a6363'
  tertiary: '#5f5e5e'
  on-tertiary: '#ffffff'
  tertiary-container: '#b4b2b2'
  on-tertiary-container: '#454545'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#ebe0e0'
  secondary-fixed-dim: '#cec4c4'
  on-secondary-fixed: '#1f1a1b'
  on-secondary-fixed-variant: '#4c4546'
  tertiary-fixed: '#e4e2e1'
  tertiary-fixed-dim: '#c8c6c6'
  on-tertiary-fixed: '#1b1c1c'
  on-tertiary-fixed-variant: '#474747'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Montserrat
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 16px
---

## Brand & Style

The design system is rooted in the intersection of high-fashion editorial aesthetics and modern digital serenity. It is designed to evoke a sense of exclusive sanctuary, catering to a clientele that values precision, luxury, and a personalized touch. 

The visual style blends **Minimalism** with **Glassmorphism**. By prioritizing expansive white space and a restricted color palette, the UI feels airy and unhurried. Glassmorphic layers introduce a sense of physical depth and tactile luxury, mimicking the high-end finishes found in a premium salon environment. Gold accents are used sparingly as a "jewelry" layer—providing focal points without overwhelming the user's journey.

## Colors

The palette is anchored by **Champagne Gold**, representing the premium nature of the service. This is paired with **Soft Blush Pink** to provide a warm, feminine undertone that remains professional and modern. 

**Charcoal** serves as the functional anchor for typography and high-contrast UI elements, ensuring legibility and a grounded feeling against the lighter background. **Crisp White** is the primary canvas color, used to maintain the "airy" brand pillar. Use transparency on white surfaces (20-60%) when implementing glassmorphic containers to allow background colors to bleed through softly.

## Typography

This design system utilizes a high-contrast typographic pairing to signal luxury. **Playfair Display** is the primary display face; its elegant serifs and varied stroke weights provide an authoritative yet graceful voice for headings and hero sections.

**Montserrat** acts as the functional counterpart. Its geometric, clean letterforms ensure that technical information, service descriptions, and booking flows remain highly readable and modern. Label styles should frequently utilize uppercase styling with increased letter-spacing to mimic fashion magazine layouts.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy for desktop screens to maintain a curated, editorial feel, while transitioning to a fluid model for smaller devices. 

- **Desktop:** 12-column grid with a 1200px max-width. Use large `xl` margins between sections to emphasize the "airy" brand pillar.
- **Mobile:** Single column with 16px side margins. 
- **Rhythm:** Spacing is strictly based on an 8px scale. Use wider padding within cards and containers than typical SaaS apps to suggest a sense of "room to breathe."

## Elevation & Depth

Hierarchy is established through **Glassmorphism** and **Ambient Shadows**. Instead of heavy shadows, the design system uses "Light Leaks" and soft, diffused blurs.

1.  **Surface Levels:** The base layer is always solid (White or Blush). Elevated surfaces (cards, modals) use a semi-transparent white background with a `backdrop-filter: blur(12px)`.
2.  **Shadows:** Shadows are highly diffused (e.g., `0 8px 32px rgba(45, 45, 45, 0.04)`). They should feel like a soft glow rather than a dark drop-shadow.
3.  **Gold Accents:** Use 1px Champagne Gold borders on active elements or primary buttons to denote "top-tier" interactive states.

## Shapes

The shape language is **Rounded**, striking a balance between organic softness and professional structure. 

Standard components like input fields and small buttons use a 0.5rem (8px) radius. Larger containers, such as promotional banners or glassmorphic cards, utilize 1rem (16px) or 1.5rem (24px) corners to feel more inviting. Circular shapes are reserved strictly for profile images or specific icon backgrounds to maintain a "pearl-like" accent.

## Components

### Buttons
- **Primary:** Champagne Gold background with White or Charcoal text. High-gloss finish or subtle gold gradient.
- **Secondary:** Transparent background with a 1px Gold or Charcoal border.
- **Tertiary:** Text-only with an underline that appears on hover, using Playfair Display for a "link" look.

### Cards
Cards should be the primary vehicle for services. Use glassmorphic backgrounds (blurred white) with a very thin (0.5px) white border to catch light. Image containers within cards should have a subtle zoom-on-hover effect.

### Input Fields
Inputs should be minimalist. A simple bottom border in Charcoal or a fully enclosed Soft Blush background with 8px rounding. Use Montserrat for placeholder text.

### Chips & Tags
Used for service categories (e.g., "Hair," "Nails"). Use a Soft Blush background with Charcoal text and 100px (pill) rounding to distinguish them from actionable buttons.

### Checkboxes & Radios
Custom-styled with Champagne Gold accents. When selected, the inner fill should use a soft gold-to-white radial gradient to mimic a metallic sheen.